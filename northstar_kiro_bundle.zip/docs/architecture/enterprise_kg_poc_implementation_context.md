# Enterprise Knowledge Graph POC — Canonical Implementation Context

This file is the repo-native source of truth for Kiro and other coding LLMs implementing the enterprise knowledge graph POC. It intentionally focuses on the design that is currently agreed, the temporary constraints of the POC, the boundaries between persistent knowledge and live evidence, and the order in which the system should be built.

## 1. What we are building

The goal is an enterprise troubleshooting knowledge system that lets an agent start from a ServiceNow incident/change and navigate from business identity to production topology, historical operational knowledge and source code, then use live observability tools to investigate the current problem.

The knowledge graph is not expected to determine root cause by itself. It provides structure, identity, history and bounded candidate regions. Semantic retrieval helps find relevant unstructured history. Live tools provide incident-time evidence. The agent performs the investigation/reasoning.

The core human-resolver mental model is:

```text
identify affected application/CI
    -> understand application topology
    -> find similar historical incidents
    -> form candidate hotspots/hypotheses
    -> query current traces/logs/deployments
    -> inspect exact deployed code where useful
    -> eliminate weak hypotheses
    -> conclude with evidence or report insufficient evidence
```

## 2. POC constraints

The first POC is deliberately narrow.

- PROD only. TST/ACC are future ApplicationInstance siblings, not part of initial implementation.
- ServiceNow Business Application is the semantic/business root.
- The PROD ApplicationInstance is connected to its CMDB CIs.
- Incidents/changes are connected to the CMDB CI supplied/linked by ServiceNow.
- The required runtime application topology is not yet available in Backstage.
- Therefore the POC must reconstruct the PROD runtime topology from approximately 30 days of AWS X-Ray traces.
- Backstage is currently queried to enrich each runtime/X-Ray node with technical metadata such as entity/resource identity, owner/team, repository/source, resource ARN/identifier and documentation/metadata where available.
- Every unique repository discovered from Backstage is Graphified once into a repository-scoped code graph/subgraph.
- Every runtime topology node whose Backstage metadata points to that repository is linked to the canonical Repository node / Graphify graph.
- Incident/change text and selected unstructured knowledge are embedded for semantic retrieval. Neo4j should be the first vector/full-text store; do not introduce a separate vector DB without measured need.
- Historical incidents are later enriched by an agent that attempts to identify affected/root-cause topology areas. It must be allowed to abstain when evidence is weak.
- New-incident X-Ray, CloudWatch and Kubernetes/deployment investigation is done through queryable MCP tools, not by persisting all logs/traces/events into Neo4j.

## 3. Data-source responsibilities

### ServiceNow — business and operational anchor

Use ServiceNow for:

- Business Application identity;
- PROD application instance/environment mapping;
- CMDB CI identity and application-instance association;
- incidents, changes, problems where available;
- incident descriptions, work notes/resolution text and timestamps;
- explicit record links that exist in source data.

Do not treat the CMDB as the canonical runtime dependency graph for this POC. The CI is crucial because it is the join point between ServiceNow operational records and the production application scope.

### AWS X-Ray — temporary topology builder + permanent live evidence tool

X-Ray has two different roles.

**POC construction role:** query/collect roughly 30 days of relevant traces, normalize observed services/resources and aggregate observed caller/callee relationships into a stable runtime application graph.

**Permanent investigation role:** query traces around an incident time window to determine what actually happened: errors, latency, failed downstream calls, unusual paths, hotspot behavior.

Do not conflate the bounded historical topology snapshot with incident-time trace evidence.

### Backstage — authoritative technical enrichment today, structural authority later

For the POC, resolve runtime/X-Ray nodes against Backstage and retrieve available:

- component/resource/catalog identity;
- owner/team;
- repository/source reference;
- resource ARN or other stable infrastructure identifier;
- system/domain relationships;
- docs/metadata;
- declared dependency information if present.

Prefer deterministic mapping using catalog refs, annotations, ARNs, resource IDs and known service identifiers. Fuzzy name matching may produce candidates but should not silently produce canonical links.

The target architecture assumes Backstage will eventually hold the maintained technical/application topology. When that becomes true, replace the POC X-Ray topology-construction provider with a Backstage topology adapter. The rest of the ontology should not require redesign.

### Graphify — deep repository/code knowledge

Backstage tells us which repository implements a runtime component. Normalize repository identity and deduplicate before Graphify processing.

For each unique repository:

- run Graphify once for the required revision/current source scope;
- create or import a repository-scoped code graph;
- keep code entities namespaced by repository and ideally graph/revision version;
- link canonical Repository to its Graphify graph;
- link every runtime component that references the repository to that Repository.

The enterprise topology should not copy every code node simply to look like one giant flat graph. Deep code structure can remain a subordinate connected subgraph.

### Neo4j — canonical persistent knowledge and retrieval surface

Neo4j stores the durable/derived knowledge model, including:

- BusinessApplication;
- ApplicationInstance(PROD);
- CMDBCI;
- X-Ray-derived RuntimeComponent nodes and direct observed dependencies for the POC;
- Backstage identities/metadata required for graph joins and traversal;
- Repository and links to Graphify subgraphs;
- Incident/Change/Problem records and relevant text representations;
- historical enrichment assertions with confidence/evidence/provenance;
- vector indexes, full-text indexes and graph traversal structures.

## 4. Persistent graph spine

Minimum conceptual spine:

```text
(:BusinessApplication)
    -[:HAS_INSTANCE]->
(:ApplicationInstance {environment: "PROD"})
    -[:HAS_CI]->
(:CMDBCI)
```

The PROD ApplicationInstance also owns/scopes the runtime topology derived from X-Ray:

```text
(:ApplicationInstance {environment:"PROD"})
    -[:HAS_RUNTIME_COMPONENT]->
(:RuntimeComponent)
```

Runtime topology uses direct observed dependencies:

```text
(:RuntimeComponent)-[:DEPENDS_ON]->(:RuntimeComponent)
```

Each X-Ray-derived node/edge must preserve provider/time-window provenance, for example:

- `topology_provider = "xray"`;
- `observation_window_start`;
- `observation_window_end`;
- `first_seen` / `last_seen` where useful;
- observation/call count or evidence summary where useful;
- source account/region/trace provenance as permitted.

Backstage resolution adds identity/context without erasing X-Ray provenance:

```text
(:RuntimeComponent)-[:MAPS_TO_BACKSTAGE]->(:BackstageEntity)
(:RuntimeComponent)-[:OWNED_BY]->(:Team)
(:RuntimeComponent)-[:IMPLEMENTED_BY]->(:Repository)
(:RuntimeComponent)-[:HAS_RESOURCE_ID]->(:ResourceIdentity)
```

Repository connects to code knowledge:

```text
(:Repository)-[:HAS_CODE_GRAPH]->(:CodeGraph)
```

or directly into a Graphify namespace if Graphify persists its own node model in the same Neo4j instance.

Operational history attaches through CI:

```text
(:Incident)-[:AFFECTS_CI]->(:CMDBCI)
(:Change)-[:TARGETS_CI]->(:CMDBCI)
```

After evidence-based enrichment, additional assertions may be created:

```text
(:Incident)-[:AFFECTS]->(:RuntimeComponent)
(:Incident)-[:SYMPTOM_OBSERVED_ON]->(:RuntimeComponent)
(:Incident)-[:ROOT_CAUSED_BY]->(:RuntimeComponent)
(:Incident)-[:RELATED_TO_CHANGE]->(:Change)
(:Incident)-[:RELATED_DEPLOYMENT]->(:Deployment)
```

Do not collapse symptom location, affected component and root-cause component into one generic relationship.

## 5. Identity and graph-writing rules

All ingestion must be rerunnable.

- Canonical IDs must be deterministic.
- Preserve source IDs (`sys_id`, catalog refs, ARNs, X-Ray service/resource identity, repository URL/slug, commit SHA).
- Normalize repository URLs so SSH/HTTPS/case/trailing `.git` variants do not create duplicate repos.
- Use Neo4j uniqueness constraints/indexes for canonical identity.
- Use idempotent upsert semantics deliberately; rerunning the same 30-day X-Ray window must not duplicate nodes/edges.
- Keep source-specific IDs/provenance even after canonical entity resolution.
- Never create a cross-source relationship without recording the match method/source. For inferred mappings also record confidence and processing/model version.
- Ambiguous mappings must remain ambiguous/unresolved instead of being silently collapsed to a guessed entity.

## 6. X-Ray 30-day topology construction algorithm

High-level implementation sequence:

1. Resolve the Business Application and PROD scope from ServiceNow.
2. Determine the X-Ray account/region/service seeds or scoping mechanism for that PROD application.
3. Query X-Ray for the configured 30-day window using bounded/paginated calls.
4. Store raw extraction checkpoints/manifests outside the canonical graph if useful for restart/replay; do not store every trace as a permanent KG node by default.
5. Parse each trace/service segment into normalized runtime identities.
6. Extract direct caller -> callee observations.
7. Normalize aliases/resource identifiers into stable RuntimeComponent candidates.
8. Aggregate repeated observations into one canonical node/edge per identity pair.
9. Track observation window, first/last observed and counts/evidence summary.
10. Upsert the topology under the PROD ApplicationInstance.
11. Run reconciliation to detect orphan/duplicate/low-confidence nodes.
12. Validate the topology on sampled traces before using it as historical-enrichment context.

The domain abstraction should be `RuntimeTopology` / `RuntimeComponent`, not `XRayGraph`, so the provider can later be replaced by Backstage.

## 7. Backstage enrichment workflow

For each normalized RuntimeComponent:

1. Collect deterministic identifiers available from X-Ray/resource metadata.
2. Query Backstage/catalog sources using those identifiers.
3. Produce zero, one or multiple candidate Backstage entities.
4. If one deterministic match exists, create `MAPS_TO_BACKSTAGE` and normalized metadata links.
5. If multiple plausible matches exist, store candidate/mapping evidence and mark unresolved for review rather than choosing arbitrarily.
6. Extract repository references from the matched Backstage entity.
7. Normalize repository identity and upsert Repository nodes.
8. Connect runtime component -> repository.
9. Preserve Backstage entity ref, source field/annotation used and mapping method.

Do not represent an observed X-Ray dependency and a declared Backstage dependency as the same source fact. They may agree, disagree or cover different time periods.

## 8. Graphify workflow

1. Gather unique repositories from Backstage-enriched runtime nodes.
2. Normalize/deduplicate repository IDs.
3. Determine the revision to Graphify. For general code knowledge current revision may be acceptable; for deployment-specific investigation resolve exact deployed commit where possible.
4. Run Graphify using an adapter/service boundary.
5. Import/reference the generated code graph with repository namespace/version.
6. Link Repository -> CodeGraph.
7. Verify every runtime node with that repository reference can traverse to the same Repository/CodeGraph rather than creating duplicate code graphs.
8. Record Graphify processing version/status/error for rebuildability.

## 9. Semantic retrieval

Semantic search is mainly for unstructured knowledge, especially:

- incident short/long description;
- resolution notes/work notes where allowed;
- change descriptions;
- runbook/document sections later;
- semantic component profiles if useful.

Search representation should retain at least:

- `search_doc_id`;
- canonical `node_id`;
- source record/locator;
- representation type;
- source/system;
- timestamps/version/hash;
- embedding model/version;
- ACL/security labels where required.

Retrieval should combine methods rather than rely on embeddings alone:

```text
structural graph scope (application/PROD/CI/component)
    + exact/full-text lookup for IDs/error codes/versions
    + vector similarity for semantic symptom text
    + graph expansion around retrieved nodes
    + optional reranking
```

Neo4j is the initial implementation for vector/full-text retrieval. Treat RAG as the retrieval workflow around this data, not as a mandatory separate database.

## 10. Historical incident/change enrichment

Raw incident -> CI linkage gives scope but does not encode where the problem actually occurred in the runtime topology.

After the base topology and repository links exist, run an offline enrichment process for historical tickets.

Input context should be bounded:

- incident/change text and resolution/work-note evidence;
- CI and BusinessApplication/PROD scope;
- candidate runtime components within that topology;
- relevant deterministic entity mentions;
- related changes/deployments if source-linked;
- optionally historical timestamps and code/deployment evidence when available.

The enrichment process may output:

- affected component(s);
- symptom-observed-on component(s);
- probable root-cause component/resource;
- related change/deployment;
- normalized symptoms;
- resolution pattern;
- evidence references;
- confidence;
- status.

Required status vocabulary should include at least:

- `ENRICHED`;
- `PARTIAL`;
- `AMBIGUOUS`;
- `INSUFFICIENT_EVIDENCE`.

Never force an incident to a hotspot. A clean abstention is valuable training/evaluation information and prevents poisoning future semantic retrieval.

Agent-generated/inferred assertions must remain distinguishable from source-of-truth relationships.

## 11. New-incident investigation architecture

The final investigation agent is built only after the knowledge foundation and live tools work independently.

Typical flow:

```text
new incident
 -> resolve CMDB CI
 -> resolve BusinessApplication + PROD instance
 -> load bounded runtime topology context
 -> semantic/hybrid search for similar historical incidents
 -> use matched affected/root-cause areas as candidate hypotheses
 -> query current X-Ray around incident window
 -> identify/score hotspots
 -> for promising hotspots query CloudWatch + Kubernetes + deployment history
 -> resolve running artifact/build to exact Git SHA when possible
 -> inspect Graphify code context for the relevant repository/version
 -> accept/reject hypotheses based on evidence
 -> conclude with evidence/confidence OR insufficient evidence
```

Historical similarity guides the search; it does not determine the answer.

## 12. MCP/live evidence tool contracts

Tools should expose capabilities, not require the model to construct vendor query syntax for every call.

### X-Ray MCP

Capabilities should include bounded operations such as:

- query traces for component + time range + filters;
- find errors/faults/latency outliers;
- get observed upstream/downstream calls in a time range;
- return representative trace IDs/evidence summaries;
- enforce pagination, time bounds and result limits.

### CloudWatch/log MCP

- map component/resource to permitted log group(s);
- execute bounded time-window query/search;
- return structured excerpts with timestamps/source identifiers;
- support correlation/trace/request IDs where possible;
- cap response size and allow follow-up pagination/refinement.

### Kubernetes/deployment MCP

- resolve component to cluster/namespace/workload;
- list pods and relevant state;
- get pod/container logs for bounded time windows;
- get Kubernetes events;
- get deployment/rollout/restart history;
- surface image/artifact version;
- where possible resolve artifact/build -> exact Git SHA.

MCP responses are evidence. Tool implementations must not assert root cause themselves.

## 13. Recommended code architecture

Do not let source APIs write Cypher directly. Keep boundaries roughly like:

```text
src or packages/
  sources/
    servicenow/
    xray/
    backstage/
    repositories/
  normalization/
    identities/
    servicenow/
    xray/
    backstage/
  graph/
    models/
    repositories/
    constraints/
    migrations/
  code_intelligence/
    graphify/
  embeddings/
  retrieval/
  enrichment/
    historical_incidents/
  mcp/
    xray/
    cloudwatch/
    kubernetes/
  investigation/
```

Preferred implementation flow per source:

```text
source adapter
 -> raw/source DTO
 -> normalization/entity resolution
 -> canonical domain model
 -> graph/index repository
 -> tests
```

Keep provider adapters replaceable. This is especially important for runtime topology because `XRay30DayTopologyProvider` must eventually be replaced by `BackstageTopologyProvider` without changing the rest of the domain model.

## 14. Recommended build stages

Implement and prove each stage before depending on it heavily.

1. Neo4j foundation: driver/session wrapper, migrations/constraints, canonical ID conventions, repository pattern.
2. ServiceNow business spine: BusinessApplication -> PROD ApplicationInstance -> CMDBCI.
3. ServiceNow history ingestion: Incident/Change records attached to CIs; preserve text/source/timestamps.
4. X-Ray extraction adapter: pagination, retries, bounded windows, fixtures.
5. X-Ray normalization/aggregation: stable RuntimeComponent IDs and direct dependency edges.
6. Persist 30-day PROD runtime topology with observation provenance.
7. Backstage adapter and deterministic runtime-node enrichment/mapping.
8. Repository normalization/deduplication.
9. Graphify adapter/import/versioning and links from Repository.
10. Embedding provider abstraction and Neo4j vector/full-text indexes.
11. Hybrid similar-incident retrieval with structural filters and canonical node linkage.
12. Historical incident enrichment workflow with strict schema, evidence and abstention.
13. Evaluation/review dataset for historical mappings and retrieval quality.
14. X-Ray live MCP.
15. CloudWatch live MCP.
16. Kubernetes/deployment live MCP.
17. Final investigation orchestrator/agent using graph + retrieval + live evidence.
18. Migration-ready Backstage topology provider abstraction and comparison tooling.

Do not start by building the final autonomous investigator while the graph foundation is still unreliable.

## 15. Testing and acceptance themes

Important tests are not only happy-path unit tests.

- ServiceNow payloads with missing/optional fields.
- API pagination/retry/throttle behavior.
- X-Ray repeated traces aggregate without duplicate nodes/edges.
- Re-running a window is idempotent.
- Runtime identity alias/normalization cases.
- Backstage deterministic match, no match and ambiguous match.
- Repository URL variants deduplicate correctly.
- Graphify failure/retry/version behavior.
- Neo4j uniqueness and relationship signature validation.
- Semantic search results link back to canonical graph nodes.
- Historical enrichment correct mapping, wrong candidate rejection and insufficient-evidence abstention.
- MCP result/time bounds and timeout/error behavior.
- Exact deployed commit resolution does not silently fall back to repository HEAD as if they were equal.

POC success is measured by trustworthy linkage/retrieval and evidence-backed investigation, not by graph visualization size.

## 16. Provenance, confidence and time

For authoritative source facts retain source system, source record/entity ref and source timestamps.

For extracted/inferred relationships retain:

- assertion type: authoritative / extracted / inferred / derived / human-validated;
- source/evidence references;
- extraction method;
- confidence;
- pipeline/model version;
- created/updated time;
- review state;
- validity/observation interval where relevant.

X-Ray-derived topology is explicitly time-bounded. Historical-agent output is explicitly inferred until validated. These distinctions must remain queryable.

## 17. Important anti-patterns

Do not:

- create separate Neo4j databases for every application instance simply to simulate namespaces;
- treat X-Ray as a permanent ontology layer instead of a topology provider/live evidence source;
- treat Backstage as if it already contains the missing runtime topology;
- copy every Backstage field into Neo4j;
- Graphify the same repository once per runtime component;
- let a similarity score directly create `ROOT_CAUSED_BY`;
- persist all raw logs/traces/Kubernetes events as graph knowledge;
- use generic `RELATED_TO` everywhere;
- infer a component because the implementation needs a non-null value;
- trust repository HEAD when investigating a deployed version;
- let external SDK response shapes leak through the entire codebase;
- construct massive unbounded prompts containing the entire enterprise graph.

## 18. Target-state migration

The POC should make runtime topology provider-swappable.

Today:

```text
TopologyProvider = XRay30DayTopologyBuilder
Backstage = runtime-node enrichment/query authority
```

Eventually:

```text
TopologyProvider = BackstageTopologyProvider
X-Ray = live observability query tool
```

Migration approach:

1. implement Backstage topology adapter that emits the same canonical RuntimeComponent/dependency model;
2. compare Backstage topology to X-Ray-derived topology during transition;
3. reconcile identity differences;
4. switch structural refresh to Backstage;
5. retire the persistent X-Ray topology builder;
6. retain X-Ray MCP for incident-time evidence.

## 19. Rule for coding LLMs

Architecture documents describe intent; observed source data defines integration reality. If actual ServiceNow/X-Ray/Backstage/Graphify payloads contradict an assumed field or mapping, do not fake the payload to match this document. Adapt the normalization/mapping design and record the discovered constraint.

When evidence or requirements are missing, make the missing information explicit in code/config/tests and keep the system honest. A partial but evidence-backed graph is more useful than a complete-looking graph full of guessed relationships.
