# Northstar Enterprise Knowledge Graph — Agent Operating Contract

This repository is being used to implement an enterprise knowledge graph and incident-resolution knowledge platform. Treat the architecture documents and Kiro steering as engineering constraints, not background reading.

## Before changing code

1. Read the relevant files under `.kiro/steering/`.
2. For any enterprise-KG task, use the canonical blueprint at `docs/architecture/enterprise_kg_poc_implementation_context.md`.
3. Inspect the existing implementation before proposing new abstractions. Use Kiro code intelligence/LSP for symbol discovery, definitions, references and diagnostics when available.
4. For ServiceNow, AWS X-Ray, Backstage, Kubernetes, CloudWatch or Graphify integrations, inspect real payloads, fixtures, schemas or existing adapters before defining fields. Never invent external-system fields to make the architecture fit.

## Non-negotiable architecture rules

- POC scope is PROD only unless the task explicitly expands it.
- ServiceNow Business Application is the business anchor.
- The PROD Application Instance connects to its relevant CMDB CIs.
- Historical incidents/changes attach through CMDB CI and are later enriched to affected/root-cause topology nodes only when evidence supports the mapping.
- Runtime application topology for the POC is reconstructed from approximately 30 days of X-Ray traces because the required topology is not yet available in Backstage.
- Backstage is queried to enrich X-Ray/runtime nodes with ownership, repository, resource and other technical metadata. Do not pretend Backstage already provides the complete runtime graph.
- Repositories discovered from Backstage are converted to Graphify code subgraphs and attached to every topology node whose Backstage metadata points to that repository.
- Neo4j is the persistent canonical graph and may also provide vector/full-text search. RAG is a retrieval pattern, not automatically a separate datastore.
- X-Ray, CloudWatch logs and Kubernetes/deployment evidence are live query tools for investigation; do not persist them into the KG as timeless facts unless a design explicitly calls for a bounded derived fact with provenance and validity.
- Inferred or agent-created relationships must carry evidence/provenance, confidence and processing version. Low-evidence mappings must be flagged unresolved rather than guessed.
- Ingestion and graph construction must be idempotent.

## Implementation discipline

Use this separation unless a reviewed design says otherwise:

`source adapter -> raw/source model -> normalization/entity resolution -> canonical domain model -> graph/search persistence`

Do not let source SDK responses leak directly into Cypher-writing code. Keep external API access, normalization, identity resolution, graph persistence, embeddings and agent reasoning independently testable.

For a substantial feature, prefer a Kiro Spec with requirements, design and discrete tasks. Implement one bounded workstream at a time. Each task must have observable acceptance criteria and tests where feasible.

## Completion standard

Before declaring implementation complete:

- inspect the diff;
- verify it still matches the canonical blueprint and relevant steering;
- run targeted tests and diagnostics;
- ensure retries/re-runs do not duplicate graph entities;
- ensure source provenance and failure states are preserved;
- ensure uncertain mappings remain uncertain rather than being converted to facts.
