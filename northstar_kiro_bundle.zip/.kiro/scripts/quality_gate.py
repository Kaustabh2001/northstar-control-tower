from __future__ import annotations

import json
import os
import py_compile
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Iterable

ROOT = Path.cwd()


def run(command: list[str], *, timeout: int = 180) -> tuple[int, str]:
    try:
        result = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            capture_output=True,
            timeout=timeout,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 1, f"{command[0]} could not run: {exc}"
    output = "\n".join(part for part in (result.stdout.strip(), result.stderr.strip()) if part)
    return result.returncode, output


def changed_python_files() -> list[Path]:
    paths: set[str] = set()
    for command in (
        ["git", "diff", "--name-only", "--diff-filter=ACMRT", "HEAD"],
        ["git", "ls-files", "--others", "--exclude-standard"],
    ):
        code, output = run(command, timeout=30)
        if code == 0:
            paths.update(line.strip() for line in output.splitlines() if line.strip().endswith(".py"))
    return sorted((ROOT / path for path in paths if (ROOT / path).is_file()), key=str)


def hook_file_from_stdin() -> Path | None:
    if sys.stdin.isatty():
        return None
    try:
        payload = json.load(sys.stdin)
    except Exception:
        return None

    def walk(value: object) -> Iterable[str]:
        if isinstance(value, dict):
            for key, child in value.items():
                if key.lower() in {"file", "filepath", "file_path", "path"} and isinstance(child, str):
                    yield child
                yield from walk(child)
        elif isinstance(value, list):
            for child in value:
                yield from walk(child)

    for candidate in walk(payload):
        path = Path(candidate)
        if not path.is_absolute():
            path = ROOT / path
        if path.suffix == ".py" and path.is_file():
            return path
    return None


def compile_files(files: list[Path]) -> list[str]:
    errors: list[str] = []
    for file in files:
        try:
            py_compile.compile(str(file), doraise=True)
        except py_compile.PyCompileError as exc:
            errors.append(str(exc))
    return errors


def executable(name: str) -> str | None:
    return shutil.which(name)


def main() -> int:
    mode = sys.argv[1] if len(sys.argv) > 1 else "fast"
    event_file = hook_file_from_stdin()
    changed = changed_python_files()
    files = [event_file] if event_file else changed
    files = [p for p in files if p is not None]

    if not files and mode != "full":
        print("Kiro quality gate: no changed Python file detected; skipped.")
        return 0
    if mode == "full" and not changed:
        print("Kiro quality gate: no changed Python files; full checks skipped.")
        return 0

    failures: list[str] = []
    compile_targets = changed if mode == "full" else files
    compile_errors = compile_files(compile_targets)
    if compile_errors:
        failures.append("Python compile errors:\n" + "\n".join(compile_errors))

    pyright = executable("pyright")
    if pyright:
        targets = [str(p.relative_to(ROOT)) for p in (changed if mode == "full" else files)]
        code, output = run([pyright, *targets], timeout=180)
        if code != 0:
            failures.append("Pyright failed:\n" + output)
    else:
        print("Kiro quality gate: pyright executable not found; LSP diagnostics are expected to provide type feedback.")

    ruff = executable("ruff")
    if ruff and mode == "full":
        targets = [str(p.relative_to(ROOT)) for p in changed]
        code, output = run([ruff, "check", *targets], timeout=120)
        if code != 0:
            failures.append("Ruff failed:\n" + output)

    if mode == "full":
        code, _ = run([sys.executable, "-c", "import pytest"], timeout=30)
        if code == 0:
            code, output = run([sys.executable, "-m", "pytest", "-q"], timeout=240)
            if code != 0:
                failures.append("Pytest failed:\n" + output)
        else:
            print("Kiro quality gate: pytest is not installed in the active interpreter; skipped.")

    if failures:
        print("\n\n".join(failures), file=sys.stderr)
        return 1

    print(f"Kiro quality gate ({mode}) passed for {len(compile_targets)} Python file(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
