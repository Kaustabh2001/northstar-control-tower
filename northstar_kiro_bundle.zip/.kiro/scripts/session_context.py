from __future__ import annotations

from pathlib import Path


def main() -> int:
    root = Path.cwd()
    blueprint = root / "docs" / "architecture" / "enterprise_knowledge_graph_implementation_blueprint.md"
    print("Northstar enterprise KG workspace context:")
    print(f"- Canonical blueprint: {blueprint.as_posix()} ({'present' if blueprint.exists() else 'MISSING'})")
    print("- POC: PROD only; ServiceNow Business Application -> PROD instance -> CMDB CI.")
    print("- Runtime topology: derive from ~30 days of X-Ray traces; Backstage currently enriches/query-resolves runtime nodes.")
    print("- Code: discover repos from Backstage, Graphify each repo, link topology nodes to repo subgraphs.")
    print("- History: incidents/changes attach to CI; hotspot/root-cause enrichment requires evidence and may abstain.")
    print("- Live evidence: X-Ray, CloudWatch and Kubernetes/deployment data are query tools, not timeless KG facts.")
    print("- Use relevant steering + canonical blueprint before architecture-significant edits.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
