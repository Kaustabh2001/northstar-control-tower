---
name: architecture-conformance-review
description: Review Northstar enterprise knowledge graph code, a diff, a spec, or a proposed design for consistency with the canonical architecture, source boundaries, provenance rules, Neo4j ontology and POC constraints. Use for reviews, before finalizing significant changes, or when implementation decisions are uncertain.
---

# Architecture conformance review

Read the canonical blueprint and relevant steering, then inspect the actual implementation/diff.

Check specifically:

1. **POC scope** — PROD only unless deliberately expanded.
2. **Business anchor** — Business Application -> Application Instance -> CMDB CI remains explicit.
3. **Runtime topology** — POC topology is derived from bounded X-Ray history with provider/window provenance; Backstage enrichment is not falsely represented as current complete runtime topology.
4. **Backstage mapping** — deterministic mapping preferred; ambiguity retained.
5. **Code linkage** — unique repos normalize to Graphify subgraphs; deployed SHA is not confused with repository HEAD.
6. **Persistent/live boundary** — graph contains durable/derived knowledge; X-Ray/log/K8s incident evidence stays query-oriented unless intentionally summarized with time/provenance.
7. **Historical enrichment** — affected/symptom/root-cause roles remain distinct; insufficient evidence is supported.
8. **Semantic retrieval** — vectors/chunks return to canonical graph IDs; no unnecessary separate vector store assumption.
9. **Provenance/confidence** — every inferred assertion is traceable and versioned.
10. **Idempotency/reconciliation** — reprocessing does not duplicate entities and stale/deleted data has a strategy.
11. **Source reality** — external fields match observed schemas/fixtures, not architecture guesses.
12. **Tests** — include ambiguous/error/retry/rerun cases, not only happy path.

When issues exist, prefer fixing them rather than merely documenting the divergence unless the divergence is an intentional design change.
