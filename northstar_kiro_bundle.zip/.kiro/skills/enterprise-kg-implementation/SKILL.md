---
name: enterprise-kg-implementation
description: Implement or modify the Northstar enterprise knowledge graph POC: ServiceNow/CMDB ingestion, 30-day X-Ray topology construction, Backstage enrichment, Graphify code graphs, Neo4j persistence/search, historical incident enrichment, or MCP observability tools. Use for concrete coding and implementation tasks in these areas.
---

# Enterprise KG implementation workflow

When this skill activates, do not begin by generating code from the user's sentence alone.

## 1. Load the design

Read `docs/architecture/enterprise_knowledge_graph_implementation_blueprint.md` and the relevant `.kiro/steering/2x-*.md` domain files. If older repository context conflicts, the canonical blueprint wins.

## 2. Inspect the repository

Use code intelligence/LSP for symbols, definitions, references and diagnostics. Locate existing adapters/models/repositories/tests before adding new layers.

For external systems, locate actual payload fixtures/schema examples. If source reality is not known, design an adapter boundary that can accept the real schema later; do not fabricate authoritative fields.

## 3. Define the slice

State internally:
- input/source contract;
- canonical entity IDs;
- normalized output;
- graph nodes/edges affected;
- provenance/confidence requirements;
- idempotency behavior;
- unresolved/error behavior;
- tests/acceptance criteria.

For a multi-module slice, create/use a Kiro Spec rather than implementing the whole architecture in one pass.

## 4. Implement in layers

Preferred order:

`source access -> raw model -> normalization/entity resolution -> canonical model -> persistence/index -> tests`

Keep business reasoning out of source adapters and vendor-specific response objects out of graph repositories.

## 5. Validate

Run relevant diagnostics/tests. Review the diff for:
- invented source fields;
- accidental PROD/non-PROD mixing;
- duplicate identity paths;
- non-idempotent writes;
- inferred edges without provenance/confidence;
- live observability persisted as timeless truth;
- historical hotspot guesses without evidence;
- repo HEAD used in place of deployed commit.

If evidence is missing, leave an explicit unresolved state and surface what data is needed next.
