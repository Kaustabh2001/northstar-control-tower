---
inclusion: auto
name: enterprise-kg-architecture
description: Canonical detailed architecture and implementation blueprint. Use for any task involving the enterprise knowledge graph, ServiceNow, CMDB, X-Ray topology, Backstage, Graphify, Neo4j, embeddings, semantic retrieval, historical incident/change enrichment, MCP observability tools, or incident-resolution implementation in this repository.
---

# Canonical architecture reference

For relevant work, treat the following live workspace file as the primary design source:

#[[file:docs/architecture/enterprise_kg_poc_implementation_context.md]]

Additional historical/background design context:

#[[file:Enterprise Knowledge Graph and Retrieval - Agent Context.md]]

If there is a conflict, prefer the detailed implementation blueprint above, then the always-on steering files, then older background context. Do not silently reconcile conflicts by guessing; identify the conflict in the design/implementation notes.
