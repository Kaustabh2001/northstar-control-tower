---
inclusion: auto
name: servicenow-graph-ingestion
description: Use when implementing or changing ServiceNow Business Application, application instance, CMDB CI, incident, problem or change ingestion and their mappings into Neo4j.
---

# ServiceNow ingestion rules

POC chain:

`BusinessApplication -> PROD ApplicationInstance -> CMDB CI`

Operational history attaches through the CI:

`Incident/Change -> affected/linked CMDB CI`

Rules:
- PROD only unless scope is explicitly expanded.
- Preserve ServiceNow sys_id/record identifiers and source timestamps.
- Do not assume CMDB is authoritative for runtime dependencies; it is the operational/business mapping surface used to anchor incidents to the application instance in this POC.
- Keep raw source payload handling separate from canonical graph models.
- Incident text, work notes/resolution text and selected change text may get semantic representations, but the raw/source record remains addressable.
- Do not map an incident directly to a runtime hotspot solely from its CI. CI identifies scope; hotspot enrichment is a separate evidence-based process.
