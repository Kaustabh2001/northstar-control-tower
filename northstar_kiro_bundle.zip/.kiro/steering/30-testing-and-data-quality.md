---
inclusion: auto
name: kg-testing-data-quality
description: Use when writing tests, fixtures, validation, ingestion reconciliation, graph quality checks, evaluation datasets, or acceptance criteria for the enterprise knowledge graph.
---

# Testing and data-quality expectations

Prioritize deterministic fixtures from sanitized real payload shapes for ServiceNow, X-Ray and Backstage. Do not build tests around fields invented from documentation alone when actual source samples are available.

Minimum important test classes:
- source adapter pagination/retry/error handling;
- normalization with missing/optional fields;
- canonical identity normalization;
- idempotent graph reruns;
- relationship signature validation;
- X-Ray repeated-trace aggregation;
- repository URL normalization and Backstage mapping ambiguity;
- embedding/search result linkage back to graph entity;
- historical enrichment positive, negative and insufficient-evidence cases;
- stale/deleted/reconciled source behavior;
- live-tool result bounding and timeout behavior.

For agent/enrichment evaluation, maintain a reviewed dataset and measure abstention/insufficient-evidence behavior as well as correct mappings. A system that guesses every incident hotspot is worse than one that explicitly abstains when evidence is weak.
