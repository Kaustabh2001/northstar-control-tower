---
inclusion: auto
name: neo4j-canonical-graph
description: Use when designing Neo4j nodes, relationships, constraints, vector/full-text indexes, Cypher repositories, graph migrations, identity rules, or retrieval traversals.
---

# Neo4j graph rules

Neo4j is the canonical persistent graph for the POC. Use explicit application-instance scoping instead of separate databases per PROD/TST/ACC.

Core conceptual hierarchy:

`BusinessApplication -[:HAS_INSTANCE]-> ApplicationInstance(PROD) -[:HAS_CI]-> CMDBCI -[:MAPS_TO/SCOPES]-> RuntimeTopologyComponent`

Runtime components connect to Backstage/catalog metadata and repositories. Repositories connect to Graphify code subgraphs. Incidents/changes connect to CIs and, after enrichment, may connect to affected/root-cause components.

Requirements:
- stable canonical IDs and uniqueness constraints;
- typed relationship vocabulary; avoid generic `RELATED_TO` as a default;
- direct edges as source truth; calculate bounded transitive impact at query time unless measured caching is justified;
- provenance/confidence/version on non-authoritative assertions;
- time/window metadata on X-Ray-derived topology;
- idempotent upserts;
- vector/full-text indexes may live in Neo4j; do not introduce a separate vector DB without a measured requirement.

Semantic retrieval is a search capability over graph-associated text/chunks. Every retrieval result should be able to return to a canonical graph entity.
