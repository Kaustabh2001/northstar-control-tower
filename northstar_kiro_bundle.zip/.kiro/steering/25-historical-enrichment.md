---
inclusion: auto
name: historical-incident-enrichment
description: Use when implementing historical incident/change analysis, hotspot mapping, affected/root-cause component inference, confidence/evidence models, enrichment agents, or review queues.
---

# Historical enrichment contract

Raw incidents linked to a CMDB CI are not yet topology-aware operational knowledge. A separate enrichment process analyzes each historical incident/change and may produce mappings such as:

- `AFFECTS -> RuntimeComponent`
- `SYMPTOM_OBSERVED_ON -> RuntimeComponent`
- `ROOT_CAUSED_BY -> RuntimeComponent/Resource`
- `RELATED_TO_CHANGE -> Change`
- `RELATED_DEPLOYMENT -> Deployment`
- resolution pattern / evidence summary / semantic representation.

The enrichment process must be allowed to return **insufficient evidence**. This is a first-class outcome, not a failure to be hidden.

For every inferred mapping preserve:
- source incident/change;
- evidence excerpts/locators or structured evidence references;
- extraction/agent/model version;
- confidence;
- review state;
- timestamp.

Do not collapse symptom location, affected area and root-cause component into one edge. They encode different causal roles.
