---
inclusion: always
---

# Working method for Kiro Auto

The project is too interconnected for blind file-by-file generation. Use this operating loop for implementation tasks.

1. **Orient first.** Determine the workstream and read the relevant steering. For enterprise-KG implementation, ensure the canonical blueprint is available.
2. **Inspect before designing.** Inspect existing code, tests, models and real sample payloads. Prefer LSP/code intelligence for symbols/references and repository search for schemas/examples.
3. **State source reality.** Separate what the architecture wants from what the current source actually exposes. If a required field/mapping is unavailable, represent it as an unresolved integration need instead of inventing it.
4. **Define the contract.** Before significant code, define input, normalized output, canonical IDs, failure modes, provenance and idempotency behavior.
5. **Implement narrow slices.** Prefer adapter -> normalization -> persistence -> tests for one source/entity path before broadening.
6. **Validate continuously.** Run diagnostics/tests after meaningful changes. Do not leave validation until the end.
7. **Review architecture conformance.** Check persistent/live boundaries, identity semantics, provenance, confidence and environment scoping.

## Spec policy

Use a Kiro Feature Spec for any workstream that changes multiple modules, source contracts, graph schema, identity logic or agent behavior. Keep specs bounded: one source pipeline or capability, not the entire enterprise system in one spec.

A good spec must include:
- explicit assumptions and unknowns;
- acceptance criteria;
- source payload/fixture expectations;
- canonical node/edge effects;
- idempotency behavior;
- error/unresolved behavior;
- tests;
- migration/backfill behavior where relevant.

## No-guess rule

When blocked by missing external-system evidence, stop that assertion at an `unknown`, `unresolved`, `not_observed` or equivalent state. Do not infer a confident topology/ownership/root-cause mapping solely to make the implementation look complete.
