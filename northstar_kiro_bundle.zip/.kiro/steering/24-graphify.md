---
inclusion: auto
name: graphify-code-subgraphs
description: Use when discovering repositories from Backstage, running Graphify, storing/querying repository code graphs, or linking runtime topology nodes to code implementation.
---

# Graphify integration rules

- Discover the unique repository set from Backstage metadata for in-scope runtime nodes.
- Create/refresh one Graphify code graph/subgraph per repository rather than attempting to reimplement code parsing.
- Every runtime/Backstage node that references a repository should connect to that repository/code graph using stable repository identity.
- Do not copy millions of function/class nodes into higher-level enterprise topology merely for convenience. Preserve a clear boundary between enterprise topology and deep code graph while keeping traversable links.
- Repository identity must normalize URL/host/path variants and retain original source locator.
- Code graph refresh/versioning must be tied to repository revision/commit when available so reasoning can distinguish current HEAD from the exact deployed version.
- For deployment investigation, prefer mapping running artifact -> build -> exact Git SHA, then compare that SHA to the previous deployed SHA; do not assume repository HEAD equals deployed code.
