---
inclusion: fileMatch
fileMatchPattern: ["**/*.py", "pyproject.toml", "tests/**/*.py"]
---

# Python implementation standards

- Target Python 3.11+ as declared by the project.
- Prefer typed interfaces, dataclasses/Pydantic models where validation is valuable, and explicit return types for public functions.
- Keep AWS/ServiceNow/Backstage/Graphify SDK or HTTP details inside source adapters.
- Normalize source payloads into internal models before graph persistence.
- Avoid large god services. Keep entity identity, normalization, persistence, embedding and reasoning logic separable.
- External I/O must have timeouts, bounded retries where safe, pagination handling and actionable errors.
- Graph writes must be idempotent; use stable canonical keys and `MERGE`/equivalent semantics deliberately.
- Preserve raw source IDs and provenance even after normalization.
- Never swallow exceptions to keep ingestion green. Quarantine/record rejected items with enough information to diagnose them.
- Tests should cover happy path, malformed/missing fields, pagination/partial data, reruns/idempotency and ambiguous mappings.
- Use existing project patterns before introducing a framework or dependency.
- Before broad refactors use LSP find-references/go-to-definition rather than textual assumptions.
