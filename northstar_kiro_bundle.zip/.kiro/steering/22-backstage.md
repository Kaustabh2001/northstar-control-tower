---
inclusion: auto
name: backstage-enrichment
description: Use when resolving X-Ray/runtime nodes against Backstage, querying Backstage ownership/resource/repository metadata, or preparing for eventual Backstage-owned topology.
---

# Backstage role in the POC

Backstage is currently a queryable enrichment source for each runtime/X-Ray node, not the source of the complete runtime graph.

Use it to resolve available technical context such as:
- component/resource identity;
- owner/team;
- repository/source link;
- resource ARN/identifier;
- system/domain relations;
- documentation/metadata;
- declared dependencies if present.

Mapping rules:
- prefer deterministic identifiers/annotations/ARNs/catalog refs over fuzzy name matching;
- retain Backstage entity refs and mapping evidence;
- if mapping is ambiguous, store candidate/unresolved state rather than selecting one silently;
- distinguish observed runtime dependency (X-Ray) from declared catalog dependency (Backstage) if both are present.

Target state: Backstage eventually becomes the maintained technical topology source. Keep provider boundaries clean so the POC X-Ray construction can be replaced without rewriting the rest of the ontology or agent-facing contracts.
