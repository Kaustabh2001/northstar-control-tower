---
inclusion: auto
name: live-evidence-mcp
description: Use when designing or implementing MCP tools for AWS X-Ray, CloudWatch logs, Kubernetes pods/logs/events, deployment history, or new-incident evidence gathering.
---

# Live evidence MCP boundary

Expose capability-oriented tools rather than forcing the model to know vendor query details.

Examples of useful contracts:
- query traces for component + time window + error/latency filters;
- get observed upstream/downstream calls for a time window;
- search CloudWatch logs for resource + time window + query;
- inspect Kubernetes workload/pods/events/logs;
- get deployment/rollout history;
- resolve running artifact/image to build/version/commit when possible.

MCP tools should return bounded, structured results with source, timestamps and pagination/continuation where needed. Avoid dumping unbounded raw logs/traces into context.

The tools gather evidence. They do not independently assert root cause. The investigation logic combines graph context, historical similarity and live evidence to identify and validate hotspots.
