---
inclusion: auto
name: xray-runtime-topology
description: Use for AWS X-Ray trace ingestion, 30-day runtime application graph construction, X-Ray node/edge identity, trace aggregation, or X-Ray MCP/query tooling.
---

# X-Ray rules

X-Ray has two roles and they must not be conflated.

## Construction role for the POC

Because the required runtime graph is not yet in Backstage, collect/inspect approximately 30 days of traces and derive a bounded runtime application topology for PROD.

The derived topology must retain:
- observation window start/end;
- source = X-Ray;
- first/last observed time where useful;
- observation/call evidence or counts where useful;
- stable normalized runtime-node identity;
- direct observed dependency edges rather than invented transitive edges.

Repeated traces must aggregate into stable nodes/edges; rerunning the same window must not duplicate topology.

## Live investigation role

For a new incident, query X-Ray around the incident window to inspect actual current/incident-time behavior. These query results are evidence, not automatically new permanent KG truth.

Do not name the canonical abstraction `XRayGraph` throughout the domain. Prefer runtime topology/component/dependency concepts with X-Ray recorded as provider/provenance so Backstage can eventually replace the construction source.
