---
inclusion: always
---

# Project core — enterprise knowledge graph POC

## Objective

Build a persistent enterprise knowledge graph that lets an AI reason from a business application down through its production runtime topology, historical operational knowledge and code implementation, while keeping live observability as queryable evidence rather than pretending all operational data is static knowledge.

## Current POC scope

- One domain / selected business application scope.
- PROD only. TST/ACC are future extensions of the same model.
- ServiceNow provides Business Application, PROD instance context, CMDB CI and incident/change history.
- Required runtime topology is not yet present in Backstage. For the POC, reconstruct it from about 30 days of AWS X-Ray traces.
- Backstage is currently an enrichment/query source for runtime nodes: ownership/team, repository/source, resource identifiers/ARNs, documentation and available metadata.
- Each unique repository in scope gets a Graphify code graph/subgraph. Runtime/Backstage topology nodes that reference the repository connect to that code graph.
- Neo4j stores the canonical graph, structured historical enrichment and semantic/vector representations needed for retrieval.

## Canonical flow

`ServiceNow BusinessApplication -> PROD ApplicationInstance -> CMDB CI -> runtime topology derived from X-Ray -> Backstage metadata enrichment -> repository links -> Graphify repo subgraphs`

Historical operational records attach to the CMDB CI. An enrichment process later links incidents/changes to affected/root-cause runtime components only when enough evidence exists.

## Persistent versus live boundary

Persist:
- identities and stable structural relationships;
- the POC runtime topology derived from the bounded 30-day X-Ray construction window, with provenance/window metadata;
- Backstage enrichment and repository mappings;
- Graphify code graphs or references to their graph representation;
- incidents/changes and their text/search representations;
- evidence-backed historical incident enrichment;
- provenance, confidence, versions and validity metadata.

Query live during new-incident investigation:
- AWS X-Ray traces/service behavior for the incident time window;
- CloudWatch logs;
- Kubernetes workload/pod/events/logs;
- deployment/rollout history and exact deployed artifact/commit where available.

## Fundamental reasoning rule

Historical similarity proposes investigation context/hypotheses. It must never be treated as proof of the current root cause. Current evidence must validate or reject it.
