---
inclusion: auto
name: semantic-graph-retrieval
description: Use when implementing embeddings, vector indexes, full-text search, similar-incident search, document chunking, GraphRAG-style retrieval, or Neo4j semantic retrieval.
---

# Semantic retrieval rules

RAG is a retrieval pattern, not a mandatory separate vector database. Start with Neo4j vector/full-text/graph retrieval unless measured scale or feature requirements justify another store.

Use semantic search mainly for unstructured evidence such as incident descriptions, resolutions/work notes, runbook/document sections and selected semantic profiles.

Prefer hybrid retrieval:
1. resolve structural scope when known (application/PROD/CI/component);
2. exact/full-text lookup for IDs, error codes, versions and literals;
3. vector similarity for semantic symptoms/descriptions;
4. graph expansion around retrieved canonical entities;
5. rerank/score if needed.

Chunks/search documents must retain canonical `node_id`, source locator, source/version/timestamps and ACL metadata where relevant. Do not duplicate the entire graph ancestry into every vector record as ontology truth.
