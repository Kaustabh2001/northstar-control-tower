# Recommended Kiro Spec decomposition

Do not create one giant spec for the whole enterprise knowledge graph. Use bounded specs so Auto has a coherent context and acceptance criteria.

Suggested order:

1. `kg-neo4j-foundation` — canonical IDs, base node/edge model, constraints, repositories, migrations.
2. `servicenow-prod-ingestion` — Business Application, PROD instance, CMDB CI and incident/change ingestion.
3. `xray-30d-topology` — trace collection, normalization and stable runtime graph aggregation.
4. `ci-runtime-topology-linking` — connect PROD/CI scope to the X-Ray-derived application topology.
5. `backstage-runtime-enrichment` — map runtime nodes to Backstage metadata with ambiguity handling.
6. `graphify-repository-linking` — repository discovery, normalization, Graphify execution/import and links.
7. `semantic-search` — incident/document embeddings, Neo4j vector/full-text indexes and hybrid retrieval.
8. `historical-incident-enrichment` — evidence-based affected/root-cause hotspot mapping with abstention.
9. `xray-live-mcp` — incident-window trace querying.
10. `cloudwatch-live-mcp` — bounded log querying.
11. `kubernetes-live-mcp` — pods/events/logs/deployment history.
12. `incident-investigation-orchestrator` — only after the graph/retrieval/live tools are independently reliable.

For complex/ambiguous work, use Feature Spec rather than Quick Spec and run requirement analysis before design. For well-understood adapter/test slices, Quick Spec is acceptable.

Every spec should explicitly answer:
- What source payloads are used?
- What is authoritative vs derived?
- Which canonical IDs are created/resolved?
- Which nodes/edges/index documents change?
- What happens when mapping is ambiguous?
- How is provenance represented?
- What happens on rerun?
- What tests prove acceptance criteria?
