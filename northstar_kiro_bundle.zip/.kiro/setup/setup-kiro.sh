#!/usr/bin/env bash
set -euo pipefail

kiro-cli settings chat.enableKnowledge true
kiro-cli settings knowledge.maxFiles 10000
kiro-cli settings knowledge.chunkSize 1024
kiro-cli settings knowledge.chunkOverlap 256
kiro-cli settings knowledge.indexType "Best"
kiro-cli settings knowledge.defaultIncludePatterns '["**/*.md","**/*.py","**/*.toml","**/*.yaml","**/*.yml","**/*.json","**/*.sql"]'
kiro-cli settings knowledge.defaultExcludePatterns '["**/.git/**","**/.venv/**","**/venv/**","**/__pycache__/**","**/.pytest_cache/**","**/node_modules/**","data/raw/**","data/exports/**","**/*.log"]'

cat <<'MSG'
Kiro settings applied. Start kiro-cli in this repository, then run:
/code status
# If Pyright is not initialized: /code init -f
/knowledge add --name northstar-architecture --path ./docs/architecture --include "**/*.md" --index-type Best
/knowledge add --name northstar-background --path . --include "Enterprise Knowledge Graph and Retrieval - Agent Context.md" --index-type Best
/knowledge add --name northstar-code --path . --include "**/*.py" --exclude "**/.venv/**" --exclude "**/__pycache__/**" --index-type Best
/knowledge show
/context show
MSG
