$ErrorActionPreference = "Stop"

Write-Host "Configuring Kiro CLI knowledge settings for Northstar..."
kiro-cli settings chat.enableKnowledge true
kiro-cli settings knowledge.maxFiles 10000
kiro-cli settings knowledge.chunkSize 1024
kiro-cli settings knowledge.chunkOverlap 256
kiro-cli settings knowledge.indexType "Best"
kiro-cli settings knowledge.defaultIncludePatterns '["**/*.md","**/*.py","**/*.toml","**/*.yaml","**/*.yml","**/*.json","**/*.sql"]'
kiro-cli settings knowledge.defaultExcludePatterns '["**/.git/**","**/.venv/**","**/venv/**","**/__pycache__/**","**/.pytest_cache/**","**/node_modules/**","data/raw/**","data/exports/**","**/*.log"]'

Write-Host ""
Write-Host "Settings applied. Start kiro-cli in this repo, then run:"
Write-Host "/code status"
Write-Host "If Pyright is not initialized: /code init -f"
Write-Host "/knowledge add --name northstar-architecture --path ./docs/architecture --include **/*.md --index-type Best"
Write-Host "/knowledge add --name northstar-background --path . --include 'Enterprise Knowledge Graph and Retrieval - Agent Context.md' --index-type Best"
Write-Host "/knowledge add --name northstar-code --path . --include **/*.py --exclude **/.venv/** --exclude **/__pycache__/** --index-type Best"
Write-Host "/knowledge show"
Write-Host "/context show"
