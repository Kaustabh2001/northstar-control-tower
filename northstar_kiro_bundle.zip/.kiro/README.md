# Kiro project configuration

This directory is designed for Kiro Auto mode without custom agents. The goal is to compensate for harness/context loss by giving the default Kiro agent a compact always-on mental model and progressively loading deeper context only when relevant.

## What is configured

- `steering/` — project invariants plus auto-loaded domain guidance.
- `skills/` — on-demand implementation and architecture-review workflows; these are skills, not custom agents.
- `hooks/` — prompt/task guardrails and deterministic Python validation.
- `scripts/` — cross-platform hook helpers.
- `settings/lsp.json` — Pyright LSP configuration for CLI code intelligence.
- `specs/README.md` — recommended workstream/spec decomposition.
- `setup/` — optional one-time Kiro CLI knowledge-base configuration.

## Canonical context

The source of truth is:

`docs/architecture/enterprise_kg_poc_implementation_context.md`

The older root-level `Enterprise Knowledge Graph and Retrieval - Agent Context.md` remains useful background. If it conflicts with the canonical blueprint, the canonical blueprint wins.

## First use

If using the Kiro IDE, steering, skills and hooks activate from the repository automatically.

If using Kiro CLI, from the repository root run:

1. `/code status` — verify Pyright is initialized. If not, run `/code init` or `/code init -f`.
2. Optionally run `.kiro/setup/setup-kiro.ps1` on Windows or `.kiro/setup/setup-kiro.sh` on bash-compatible systems to tune Kiro knowledge settings.
3. Inside Kiro CLI, add the architecture/code knowledge entries shown by the setup script if you want persistent semantic knowledge search.
4. Use Auto model selection. For complex architecture or entity-resolution work, raise `/effort` rather than creating another agent.

Use `/context show` occasionally. The always-on files are intentionally compact; the full blueprint is loaded through auto steering only for relevant tasks.
